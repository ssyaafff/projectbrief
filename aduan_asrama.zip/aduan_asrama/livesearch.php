<?php

include("config.php");
if(isset($_POST['input'])){

	$input = $_POST['input'];

	$query = "SELECT * FROM senarai_aduan WHERE nama_pelajar LIKE '{$input}%' OR no_dorm LIKE '{$input}%' OR kategori LIKE '{$input}%'";

	$result = mysqli_query($mysqli, $query);

	if(mysqli_num_rows($result) > 0){?>

		<table class="table table-bordered table-striped mt-4">
			<thead>
				<tr>
				<th>NO DORM</th>
                <th>NAMA PELAJAR</th>
                <th>KATEGORI</th>
                <th>KETERANGAN</th>
				</tr>
			</thead>

			<tbody>
				<?php

				while($row = mysqli_fetch_assoc($result)){

					$no_dorm = $row["no_dorm"];
					$nama_pelajar = $row["nama_pelajar"];
					$kategori = $row["kategori"];
					$keterangan = $row["keterangan"];

				?>

				<tr>
					<td><?php echo $no_dorm;?></td>
					<td><?php echo $nama_pelajar;?></td>
					<td><?php echo $kategori;?></td>
					<td><?php echo $keterangan;?></td>
				</tr>

				<?php
			}

			?>
			</tbody>
		</table>


		<?php

	}else{

		echo "<h6 class='text-danger text-center mt-3'>Tiada data dijumpai</h6>";
	}
}
?>