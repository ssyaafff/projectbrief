<!DOCTYPE html>
<html>
<head>
    <title>Aduan Asrama</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <div class="container" style="max-width: 50%;">

        <div class="text-center mt-5 mb-4">
            <h2>Semak Aduan</h2>
        </div>

        <input type="text" class="form-control" id='aduan_asrama' autocomplete="off" placeholder="Semak Aduan ...">
    </div>

    <div id="searchresult"></div>

    <!-- Butang Kembali -->
    <div class="text-center mt-3">
        <button class="btn btn-primary" id="backButton">Kembali</button>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){

            $("#aduan_asrama").keyup(function(){
                var input = $(this).val();

                if(input != ""){
                    $.ajax({
                        url: "livesearch.php",
                        method: "POST",
                        data: {input: input},
                        success: function(data){
                            $("#searchresult").html(data);
                            $("#searchresult").css("display", "block");
                        }
                    });
                } else {
                    $("#searchresult").css("display", "none");
                }
            });

            // Fungsi untuk butang "Kembali"
            $("#backButton").click(function(){
                window.history.back();
            });
        });
    </script>
</body>
</html>
