<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection
include 'config.php';

// Process registration form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validate input
    if (empty($username) || empty($password)) {
        $error_message = "Nama Penuh dan Kata Laluan diperlukan.";
    } else {
        // Insert user data into the table without hashing the password
        $sql = "INSERT INTO user (username, password) VALUES (?, ?)";

        // Use prepared statement to prevent SQL Injection
        if ($stmt = $mysqli->prepare($sql)) {
            $stmt->bind_param("ss", $username, $password); // "ss" means two string parameters
            if ($stmt->execute()) {
                $success_message = "Pendaftaran berjaya untuk Nama: $username!";
            } else {
                $error_message = "Ralat semasa pendaftaran: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error_message = "Ralat persediaan arahan SQL: " . $mysqli->error;
        }
    }

    // Close connection
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna Baharu</title>
    <style>
        /* General styles for body and container */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-image: url('kvs.png');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent background for the form */
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .logo img {
            width: 150px;
            height: auto;
            margin-bottom: 20px;
        }

        .form-container {
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
        }

        input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }

        .login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            color: #4CAF50;
            text-decoration: none;
        }

        .back-link {
            margin-top: 20px;
            text-align: center;
        }

        .back-link a {
            color: #007BFF;
            text-decoration: none;
            font-weight: bold;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="logo">
            <img src="logokvsepang.jpg" alt="Logo">
        </div>

        <div class="form-container">
            <h2>Daftar Akaun Baru</h2>
            
            <!-- Display success or error message -->
            <?php if (isset($success_message)): ?>
                <div class="success"><?php echo $success_message; ?></div>
                <div class="login-link">
                    <p>Sudah mendaftar? <a href="login.php">Log masuk</a></p>
                </div>
            <?php elseif (isset($error_message)): ?>
                <div class="error"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <!-- Registration form -->
            <form action="" method="POST">
                <label for="ic">NAMA PENUH: </label>
                <input type="text" id="username" name="username" required>

                <label for="password">KATA LALUAN: </label>
                <input type="password" id="password" name="password" required>

                <button type="submit">DAFTAR</button>
            </form>

            <div class="back-link">
                <strong><a href="index.php">KEMBALI</a></strong>
            </div>
        </div>
    </div>

</body>
</html>