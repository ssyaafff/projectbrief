<?php
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Aduan Pelajar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: blue;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333; 
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            padding: 20px;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #4a90e2;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #e0f7fa;
        }

        a {
            text-decoration: none;
        }

        .button {
            background-color: #4a90e2; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            font-size: 16px;
        }

        .button:hover {
            background-color: #357ab8;
            transform: scale(1.05);
        }

        .add-button {
            background-color: #5cb85c; 
        }

        .add-button:hover {
            background-color: #4cae4c; 
        }

        .confirm-link {
            color: #d9534f; 
        }

        .logout-button {
            background-color: #d9534f; 
        }

        .logout-button:hover {
            background-color: #c9302c; 
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            z-index: 1000;
            text-align: center;
            padding: 20px;
        }

        .popup img {
            max-width: 90%;
            max-height: 90%;
            border-radius: 10px;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
        }

        @media (max-width: 768px) {
            table {
                width: 100%;
            }
            .button {
                width: 100%;
                margin: 5px 0;
            }
        }
    </style>
    <script>
        function showPopup(imageSrc) {
            const popup = document.getElementById('popup');
            const popupImage = document.getElementById('popupImage');
            const overlay = document.getElementById('overlay');

            popupImage.src = imageSrc;
            popup.style.display = 'block';
            overlay.style.display = 'block';
        }

        function closePopup() {
            const popup = document.getElementById('popup');
            const overlay = document.getElementById('overlay');

            popup.style.display = 'none';
            overlay.style.display = 'none';
        }
    </script>
</head>
<body>
    <h2>SENARAI ADUAN ASRAMA</h2>
    <center>
        <table>
            <tr>
                <th>NO DORM</th>
                <th>NAMA PELAJAR</th>
                <th>KATEGORI</th>
                <th>KETERANGAN</th>
                <th>GAMBAR KEROSAKAN</th>
                <th>TINDAKAN</th>
            </tr>
            
            <?php
            $query = "SELECT * FROM senarai_aduan";
            $result = mysqli_query($mysqli, $query); 

            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) { 
                    echo "<tr>";
                    echo "<td>" . $row["no_dorm"] . "</td>";
                    echo "<td>" . $row["nama_pelajar"] . "</td>";
                    echo "<td>" . $row["kategori"] . "</td>";
                    echo "<td>" . $row["keterangan"] . "</td>";
                    echo "<td><a href='#' onclick=\"showPopup('uploads/" . $row["gambar"] . "')\">Klik untuk lihat</a></td>";
                    echo "<td>
                        <a class='confirm-link' href=\"delete.php?id=$row[no_dorm]\" onClick=\"return confirm('Adakah anda pasti?')\">
                            <i class='fas fa-check'></i> SELESAI </a>
                      </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>Tiada data pelajar.</td></tr>";
            }
            ?>          
        </table>
        <div class="footer">
            <a href="index.php" class="button logout-button">
                <i class="fas fa-sign-out-alt"></i> Log Keluar
            </a>
        </div>
    </center>

    <!-- Popup Image -->
    <div id="popup" class="popup">
        <img id="popupImage" src="" alt="Gambar Kerosakan">
        <br><br>
        <button class="button" onclick="closePopup()">Tutup</button>
    </div>

    <!-- Overlay -->
    <div id="overlay" class="overlay" onclick="closePopup()"></div>
</body>
</html>
