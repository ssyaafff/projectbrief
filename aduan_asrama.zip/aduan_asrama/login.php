<?php
include ('config.php');

session_start();

$error_message = ''; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($mysqli, $_POST["username"]);
    $password = mysqli_real_escape_string($mysqli, $_POST["password"]);

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM user WHERE username=? AND password=?";
    $stmt = mysqli_prepare($mysqli, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $username, $password); // "ss" for two string parameters

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $row = mysqli_fetch_array($result);

    if ($row) {
        if ($row["usertype"] == "user") {
            $_SESSION["username"] = $username;
            header("Location: add.php");
            exit();
        } elseif ($row["usertype"] == "admin") {
            $_SESSION["username"] = $username;
            header("Location: homepage.php");
            exit();
        }
    } else {
        $error_message = "Nama atau Kata Laluan anda salah!";
    }

    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Login</title>
    <style>
        html, body {
            font-family: Arial, sans-serif;
            height: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('kvs.png');
            background-size: cover;
            background-position: center;
        }
        .form-container {
            width: 100%;
            max-width: 400px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .form-title {
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .input-container {
            position: relative;
            margin-bottom: 20px;
        }
        .form-input {
            width: 100%;
            padding: 10px 40px;
            border: 1px solid #cccccc;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        .form-input:focus {
            border-color: #4CAF50;
            outline: none;
        }
        .input-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .form-submit {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .form-submit:hover {
            background-color: #45a049;
            transform: translateY(-2px);
        }
        .back-link {
            margin-top: 20px;
        }
        .back-link a {
            color: #007BFF;
            text-decoration: none;
            font-weight: bold;
        }
        .back-link a:hover {
            text-decoration: underline;
            color: #0056b3;
        }
        .error-message {
            color: red;
            margin-bottom: 10px;
        }
        .form-container img {
            display: block;
            margin: 0 auto 20px;
            max-width: 100px; /* Atur ukuran maksimal logo */
         }
    </style>
</head>
<body>
    <form action="#" method="POST">
        <div class="form-container">
            <img src="logokvsepang.jpg" alt="Logo" style="width: 100px; margin-bottom: 20px;">
            <div class="form-title">Sila Log Masuk</div>
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <div class="input-container">
        <i class="fas fa-id-card input-icon"></i>
        <input type="text" class="form-input" name="username" placeholder="NAMA PENGGUNA" required>
    </div>
    <div class="input-container">
        <i class="fas fa-lock input-icon"></i>
        <input type="password" class="form-input" name="password" placeholder="KATA LALUAN" required>
    </div>
        <input type="submit" value="LOG MASUK" class="form-submit" name="login">
        <div class="back-link">
        <a href="index.php">KEMBALI</a>
    </div>
</div>

    </form>
</body>
</html>
