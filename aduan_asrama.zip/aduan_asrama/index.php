<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Asrama Kolej Vokasional Sepang </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            text-align: center;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            position: relative; /* Needed for the overlay */
            overflow: hidden; /* Prevents scrolling */
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('kvs.png') no-repeat center center/cover; /* Adjust the path */
            opacity: 0.7; /* Increase opacity for a darker overlay */
            z-index: 1; /* Place it behind the content */
        }
        .dark-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Black overlay with 50% opacity */
            z-index: 1; /* Place it behind the content */
        }
        .container {
            width: 80%; /* Smaller width */
            max-width: 400px; /* Limit max width */
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9); /* White background with slight transparency */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative; /* Needed to place it above the overlay */
            z-index: 2; /* Place it above the overlay */
        }
        .logo {
            width: 100px; /* Smaller logo size */
            margin-bottom: 15px;
        }
        h1 {
            font-size: 20px;
            color: #333;
        }
        p {
            font-size: 14px;
            color: #666;
        }
        .button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s; /* Added transform and box-shadow for smooth transition */
        }
        .button:hover {
            background-color: #2980b9; /* Darker background on hover */
            transform: translateY(-2px); /* Slightly lift the button */
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
        }
    </style>
</head>
<body>

<div class="dark-overlay"></div> <!-- Dark overlay for background -->
<div class="container">
    <!-- Logo -->
    <img src="logokvsepang.jpg" alt="Logo" class="logo">
    
    <!-- Title and Message -->
    <h1>Selamat datang ke E-Aduan Asrama Kolej Vokasional Sepang</h1>
    <p>Sila log masuk atau Daftar terlebih dahulu</p>
    
    <!-- Button to Redirect to Login Page -->
    <a href="login.php" class="button">Pergi Ke Halaman Log Masuk Pengguna</a>
    
    <!-- Button to Redirect to Sign Up Page -->
    <a href="signup.php" class="button">Daftar Sebagai Pengguna Baharu</a>

    <!-- Button to Redirect to Semak Aduan Page -->
    <a href="semakaduan.php" class="button">Menyemak Aduan</a>
</div>

</body>
</html>