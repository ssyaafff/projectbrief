<?php
include 'config.php';

if (isset($_POST['hantar'])) {
    // Dapatkan data daripada borang
    $no_dorm = $_POST['no_dorm'];
    $nama_pelajar = $_POST['nama_pelajar'];
    $kategori = $_POST['kategori'];
    $keterangan = $_POST['keterangan'];

    // Semak sama ada fail dimuat naik
    $file_name = $_FILES['gambar']['name'];
    $file_tmp = $_FILES['gambar']['tmp_name'];
    $upload_dir = "uploads/";

    // Pastikan folder 'uploads/' wujud
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Buat folder jika tiada
    }

    // Hasilkan nama unik untuk fail
    $new_file_name = time() . "_" . basename($file_name); 
    $uploaded_file = $upload_dir . $new_file_name;

    // Muat naik fail
    if (!empty($file_name)) {
        if (move_uploaded_file($file_tmp, $uploaded_file)) {
            echo "Fail berjaya dimuat naik!<br>";
        } else {
            echo "Ralat semasa memuat naik fail.<br>";
        }
    } else {
        $new_file_name = ""; // Tiada gambar dimuat naik
    }

    // Sediakan penyataan SQL
    $stmt = $mysqli->prepare("INSERT INTO senarai_aduan (no_dorm, nama_pelajar, kategori, keterangan, gambar) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $no_dorm, $nama_pelajar, $kategori, $keterangan, $new_file_name);

    // Laksanakan penyataan SQL
    if ($stmt->execute()) {
        echo "<script>alert('Aduan anda telah diterima! Sila tunggu beberapa hari untuk Warden memeriksa stok barang dan kerosakan barang.'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $stmt->error; // Paparkan mesej ralat jika berlaku
    }

    // Tutup penyataan
    $stmt->close();
}

// Tutup sambungan pangkalan data
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penambahan Aduan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: linear-gradient(to right, #ADD8E6, #B2E0E5);
            font-family: 'Arial', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        h2 {
            text-align: center;
            padding-top: 10px;
            color: #333;
            font-weight: bold;
        }
        .form-container {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            width: 400px;
            transition: transform 0.3s;
        }
        .form-container:hover {
            transform: scale(1.02);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        td {
            padding: 10px;
        }
        input[type="text"], textarea, select, input[type="file"] {
            width: 100%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 5px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        input[type="text"]:focus, textarea:focus, select:focus, input[type="file"]:focus {
            border-color: #0072ff;
            outline: none;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        input[type="submit"], .back-button {
            background-color: #0072ff;
            color: white;
            border: none;
            padding: 15px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s, transform 0.3s;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #28a745; /* Tukar kepada hijau semasa hover */
            transform: translateY(-2px);
        }
        .back-button:hover {
            background-color: #FF0000;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2> E-Aduan Asrama KV Sepang </h2>
        <form action="" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td>No. Dorm</td>
                    <td>:</td>
                    <td>
                        <input type="text" name="no_dorm" required>
                    </td>
                </tr>
                <tr>
                    <td>Nama Pelajar</td>
                    <td>:</td>
                    <td>
                        <input type="text" name="nama_pelajar" required>
                    </td>
                </tr>
                <tr>
                    <td><label for="kategori">Jenis Kategori:</label></td>
                    <td>:</td>
                    <td>
                        <select name="kategori" id="kategori" required>
                            <option value="">--Pilih Kategori--</option>
                            <option value="Fasiliti">Fasiliti</option>
                            <option value="Elektrikal">Elektrikal</option>
                            <option value="Perabot">Perabot</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Keterangan</td>
                    <td>:</td>
                    <td>
                        <textarea name="keterangan" required></textarea>
                    </td>
                </tr>
                <tr>
                    <td>Gambar</td>
                    <td>:</td>
                    <td>
                        <input type="file" name="gambar" accept="image/*">
                    </td>
                </tr>
                <tr>
                    <td colspan="3"><input type="submit" name="hantar" value="Hantar"></td>
                </tr>
            </table>
        </form>
        <!-- Butang Pulang ke Halaman Utama -->
        <button class="back-button" onclick="window.location.href='index.php'">Kembali</button>
    </div>
</body>
</html>
