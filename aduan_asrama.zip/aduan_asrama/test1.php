<?php
require 'vendor/autoload.inc.php'; // Pastikan autoloader diimport di peringkat awal

use Dompdf\Dompdf; // Pindahkan 'use' ke luar blok kod

$postData = $uploadedFile = $statusMsg = '';
$msgClass = 'errordiv';

if (isset($_POST['hantar'])) {
    // Ambil data daripada borang
    $no_dorm = $_POST['no_dorm'];
    $nama_pelajar = $_POST['nama_pelajar'];
    $kategori = $_POST['kategori'];
    $keterangan = $_POST['keterangan'];

    // Semak sama ada fail gambar dimuat naik
    $file_name = $_FILES['gambar']['name'];
    $file_tmp = $_FILES['gambar']['tmp_name'];
    $upload_dir = "uploads/";

    // Pastikan folder 'uploads/' wujud
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Buat folder jika tiada
    }

    // Hasilkan nama unik untuk fail
    $new_file_name = time() . "_" . basename($file_name);
    $uploaded_file = $upload_dir . $new_file_name;

    // Muat naik fail gambar
    if (!empty($file_name)) {
        if (move_uploaded_file($file_tmp, $uploaded_file)) {
            $statusMsg = "Gambar berjaya dimuat naik!";
        } else {
            $statusMsg = "Ralat semasa memuat naik gambar.";
        }
    } else {
        $new_file_name = ""; // Jika tiada gambar dimuat naik
    }

    // Pastikan semua medan borang telah diisi
    if (!empty($no_dorm) && !empty($nama_pelajar) && !empty($kategori) && !empty($keterangan)) {

        // Sediakan data untuk PDF
        $dompdf = new Dompdf();

        // Kandungan untuk PDF
        $htmlContent = "<h2>Aduan Asrama</h2>
            <p><b>No. Dorm:</b> $no_dorm</p>
            <p><b>Nama Pelajar:</b> $nama_pelajar</p>
            <p><b>Kategori:</b> $kategori</p>
            <p><b>Keterangan:</b> $keterangan</p>";

        if (!empty($uploaded_file)) {
            $htmlContent .= "<p><b>Gambar:</b></p><img src='$uploaded_file' style='width:300px;'>";
        }

        $dompdf->loadHtml($htmlContent);

        // Tetapkan saiz kertas dan orientasi
        $dompdf->setPaper('A4', 'portrait');

        // Render PDF
        $dompdf->render();

        // Hantar PDF ke pelayar untuk dimuat turun
        $dompdf->stream("Aduan_Asrama.pdf", ["Attachment" => 1]);
        exit;

    } else {
        $statusMsg = 'Sila isi semua medan.';
    }
}
?>


<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Aduan Asrama KV Sepang</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: linear-gradient(to right, #ADD8E6, #B2E0E5);
            font-family: 'Arial', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            width: 400px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
        }
        td {
            padding: 10px;
        }
        input[type="text"], textarea, select, input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            background-color: #0072ff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #28a745;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>E-Aduan Asrama KV Sepang</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td>No. Dorm</td>
                    <td><input type="text" name="no_dorm" required></td>
                </tr>
                <tr>
                    <td>Nama Pelajar</td>
                    <td><input type="text" name="nama_pelajar" required></td>
                </tr>
                <tr>
                    <td>Kategori</td>
                    <td>
                        <select name="kategori" required>
                            <option value="">--Pilih Kategori--</option>
                            <option value="Fasiliti">Fasiliti</option>
                            <option value="Elektrikal">Elektrikal</option>
                            <option value="Perabot">Perabot</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Keterangan</td>
                    <td><textarea name="keterangan" required></textarea></td>
                </tr>
                <tr>
                    <td>Gambar</td>
                    <td><input type="file" name="gambar" accept="image/*"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="hantar" value="Hantar"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>